/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.ajax.ejax_example.controller;

import demo.ajax.ejax_example.entity.Contacts;
import demo.ajax.ejax_example.entity.Student;
import java.util.ArrayList;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Kalhara
 */
@Controller
public class StudentController {

    public final static ArrayList<Student> studentList = new ArrayList<>();
    public static ArrayList<Contacts> contactses = new ArrayList<>();

    @RequestMapping(value = {"/home",""})
    public ModelAndView loadHome() {
        return new ModelAndView("Home");
    }

    @RequestMapping(value = "add/student", method = RequestMethod.POST)
    @ResponseBody
    public ModelMap addStudent(@RequestBody Student student) {
        System.out.println("demo.ajax.ejax_example.controller.StudentController.addStudent()");
        System.out.println("Student = " + student);
        studentList.add(student);
        return new ModelMap("studentList", studentList);
    }

    @RequestMapping(value = "get/students", method = RequestMethod.GET)
    @ResponseBody
    public ModelMap getStudents() {
        System.out.println("demo.ajax.ejax_example.controller.StudentController.getStudents()");
        if (studentList.isEmpty()) {
            contactses = new ArrayList<>();
            contactses.add(new Contacts(1, "Email", "k0712955386@gmail.com"));
            contactses.add(new Contacts(1, "Tel", "07152655"));
            contactses.add(new Contacts(1, "Other", "bla bla bla.."));
            studentList.add(new Student(1, "Kalhara", "Galle", contactses));
        }
        return new ModelMap("studentList", studentList);
    }

    @RequestMapping(value = "search/student", method = RequestMethod.POST)
    @ResponseBody
    public Student searchStudent(@RequestParam("stName") String stName) {
        System.out.println("demo.ajax.ejax_example.controller.StudentController.searchStudent()");
        for (Student student : studentList) {
            if (student.getName().contains(stName)) {
                return student;
            }
        }
        return null;
    }
}
